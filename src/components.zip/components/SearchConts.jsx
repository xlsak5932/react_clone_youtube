import React from 'react';

const SearchConts = () => {
  return <div>SearchConts</div>;
};

export default SearchConts;
