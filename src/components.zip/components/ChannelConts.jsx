import React from 'react';

const ChannelConts = () => {
  return <div>ChannelConts</div>;
};

export default ChannelConts;
